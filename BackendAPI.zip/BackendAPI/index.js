const axios = require('axios')
const express = require('express')

const port = 3001

const app = express()

app.use(express.json())



app.get('/pokemon', async (request, response) => {
    const { data } = await axios.get("https://pokeapi.co/api/v2/pokemon");
    return response.json( data )
})


app.listen(port, () => {
    console.log(`🚀 Server started on port ${port}`)
})